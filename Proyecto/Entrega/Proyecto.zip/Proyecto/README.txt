La base de datos escogida ha sido Human Activity Recognition using Smartphones.

Los datos utilizados para la lectura, dentro del conjunto de ficheros disponible en la base de datos de la UCI, han sido los archivos X_train.txt, y_train.txt, X_test.txt e y_test.txt. Para que puedan ser leídos, estos cuatro ficheros deberán estar dentro del directorio datos. Es decir, el acceso a los ficheros es:

./datos/X_train.txt
./datos/y_train.txt
./datos/X_test.txt
./datos/y_test.txt